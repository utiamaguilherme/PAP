import Text.Printf

andTres :: Bool -> Bool -> Bool -> Bool
andTres True True True = True
andTres _ _ _ = False

btoS :: Bool -> String
btoS True = "True"
btoS False = "False"

main = do
	a <- getLine
	let boola = (read a :: Bool)

	b <- getLine
	let boolb = (read b :: Bool)

	c <- getLine
	let boolc = (read c :: Bool)	

	printf "%s\n" $ btoS (andTres boola boolb boolc)
