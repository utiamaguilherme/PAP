import Text.Printf

area a = 3.14159 * a * a

main = do
        a <- getLine
        let floata = (read a :: Double)
        printf "A=%.4f\n" $ area(floata)


