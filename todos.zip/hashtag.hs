import Text.Printf

(#) :: String -> String -> String



main = do
	a <- getLine
	b <- getLine
	
	printf "Final: %s\n" a#b
