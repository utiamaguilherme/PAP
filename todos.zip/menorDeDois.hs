import Text.Printf

menor :: (Int,Int) -> Int
menor(a,b) | (a<b) = a
           | otherwise = b

main = do
	a <- getLine
	let inta = (read a :: Int)
	b <- getLine
	let intb = (read b :: Int)
	printf "Menor de %d e %d eh %d\n" (inta) (intb) (menor(inta,intb))
