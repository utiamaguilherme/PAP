import Text.Printf

menor :: (Int,Int) -> Int
menor(a,b) | (a<b) = a
           | otherwise = b

menorTres :: (Int,Int,Int) -> Int
menorTres(a,b,c) | (a<b) = menor(a,c)
                 | (a<c) = b
                 | (b<c) = menor(a,b)
                 | (b<a) = c
                 | (c<a) = menor(c,b)
                 | otherwise = a

main = do
	a <- getLine
	let inta = (read a :: Int)
	b <- getLine
	let intb = (read b :: Int)
	c <- getLine
	let intc = (read c :: Int)
	printf "Menor de %d e %d e %d eh %d\n" (inta) (intb) (intc) (menorTres(inta,intb,intc))
