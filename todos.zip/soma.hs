soma :: Num a => (a, a) -> a
soma(a,b) = a + b

main = do 
	a <- getLine
	let inta = (read a :: Int)
	b <- getLine
	let intb = (read b :: Int)
	putStr $ "X = "; 
	print $ soma(inta,intb)
