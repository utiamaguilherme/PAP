#include <bits/stdc++.h>
#include <curl/curl.h>
#include "include/rapidjson/document.h"
#include "include/rapidjson/writer.h"
#include "include/rapidjson/stringbuffer.h"

using namespace std;
using namespace rapidjson;


//////////////// Classe Pessoa ////////////
vector<string> inicializa(vector<string>);
class Pessoa {
    string matricula;
    string cpf;

public:

    Pessoa(string cpf, string matricula){
        this -> matricula = matricula;
        this -> cpf = cpf;
    }


    string getCpf(){
        return cpf;
    }

    string getMatricula(){
        return matricula;
    }


    void show(){
        string ret = "Matricula: "+getMatricula() + " cpf: "+getCpf();
        cout << ret << endl;
    }

};


vector<Pessoa> negado;
vector<Pessoa> correto;
vector<string> alunos, professores, servidores;

class Catraca {
    int catraca;
    vector<string> acessoCatraca;
public:
    vector<string> matricula;
    Catraca(int id, int alunos, int servidores, int professores){
        this->catraca = id;
        if(alunos){
            this->acessoCatraca.push_back("Alunos");
        }
        if(servidores){
            this->acessoCatraca.push_back("Servidores");
        }
        if(professores){
            this->acessoCatraca.push_back("Professores");
        }
        this->matricula = inicializa(this->acessoCatraca);
    }

    bool find(string matricula){

        for(string c : this->matricula){
            if(c == matricula)
                return true;
        }
        return false;

    }

    void passarCatraca(Pessoa p){
        if(this->find(p.getMatricula())){
            correto.push_back(p);
        }
        else
            negado.push_back(p);
    }
};


///////////////// Variaveis Globais ////////

string data;
vector<Pessoa> user;
pair<string, bool> verificacao;
vector<Catraca> catracas;


/////////////// Funções //////////


size_t writeCallback(char* buf, size_t size, size_t nmemb, void* up){ //callback must have this declaration
    //buf is a pointer to the data that curl has for us
    //size*nmemb is the size of the buffer

    for (int c = 0; c<size*nmemb; c++)
    {
        data.push_back(buf[c]);
    }
    return size*nmemb; //tell curl how many bytes we handled
}

vector<string> inicializa(vector<string> accepted){
    CURL* curl; //our curl object

    curl_global_init(CURL_GLOBAL_ALL); //pretty obvious
    curl = curl_easy_init();
    curl_easy_setopt(curl, CURLOPT_URL, "http://127.0.0.1:5000/getRegisters");
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, &writeCallback);
    curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L); //tell curl to output its progress
    curl_easy_perform(curl);
    cout << endl << data << endl;
    // cin.get();
    curl_easy_cleanup(curl);
    curl_global_cleanup();
    Document d;
    d.Parse(data.c_str());

    vector<string> accept;

    for(string c : accepted){
        const Value& alunos_arr = d[c.c_str()];
        for(auto& a : alunos_arr.GetArray()){
             const Value& aluno = a["matricula"];
             accept.push_back(aluno.GetString());
        }
    }
    return accept;
}


void HttpSendBuffer() {
    Document d;
    StringBuffer s;
    Writer<StringBuffer> writer(s);
    writer.StartObject();
    writer.String("Aceitos");
    writer.StartArray();
    for(int i=0; i<correto.size(); i++){
        string a = correto[i].getCpf() + " " + correto[i].getMatricula();
        writer.String(a.c_str());
    }
    writer.EndArray();
    writer.String("Rejeitados");
    writer.StartArray();
    for(int i=0; i<negado.size(); i++){
        string a = negado[i].getCpf() + " " + negado[i].getMatricula();
        writer.String(a.c_str());
    }
    
    writer.EndArray();
    writer.EndObject();
    d.Parse(s.GetString());

    CURL * curl;

    curl_global_init(CURL_GLOBAL_ALL);
    curl = curl_easy_init();

    curl_easy_setopt(curl, CURLOPT_URL, "http://localhost:5000/recebe");
    struct curl_slist *headers=NULL;
    headers = curl_slist_append(headers, "Accept: application/json");
    headers = curl_slist_append(headers, "Content-Type: application/json");
    headers = curl_slist_append(headers, "charsets: utf-8");
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, s.GetString());
    curl_easy_perform(curl);

}



int main(void){
    int quantidadeCatraca;
    cout << "Ola, digite a quantidade de catracas existentes: ";
    cin >> quantidadeCatraca;
    int cat1, cat2, cat3;
    for(int i=0; i<quantidadeCatraca; i++){
        cout << "\n\nEssa catraca aceita quais pessoas?\n";
        cout << "Digite 0. Nao\nDigite 1. Sim\n";
        cout << "Alunos: ";
        cin >> cat1;
        cout << "Servidores: ";
        cin >> cat2;
        cout << "Professores: ";
        cin >> cat3;
        catracas.push_back(Catraca(i, cat1, cat2, cat3));

    }
    cout << "Ola, digite a quantidade de pessoas a serem registradas: ";
    int k;  cin >> k;
    while(k--){
        int cont = 0;
        bool flag = false;
        string matricula, nome, cpf;
        cout << "Digite sua matricula\n";
        cin >> matricula;
        cout << "Digite seu CPF\n";
        cin >> cpf;
        getchar();
        cout << "Digite seu nome completo\n";
        getline(cin, nome);
        int catraca;
        cout << "Qual catraca deseja acessar:\n";
        for(int i=0; i<catracas.size(); i++){
            cout << i+1 << endl;
        }
        cin >> catraca;
        while(catraca < 0 or catraca > quantidadeCatraca-1){
            cout << "Digitou um valor invalido, digite novamente: ";
            cin >> catraca;
        }

        Pessoa p = Pessoa(cpf, matricula);
        user.push_back(p);
        catracas[--catraca].passarCatraca(p);
    }

    HttpSendBuffer();

    return 0;

}
