from flask import Flask
from flask import request
import simplejson as json
from collections import namedtuple

app = Flask(__name__)

Person = namedtuple('Person', 'cpf matricula')

personsTest = {
    'Professores' : [Person('01261393937', '12345789'), Person('99999999999', '2061811320'), Person('987654321', '2014159264')],
    'Alunos' : [Person('1593572486', '211011413'), Person('28466482', '6786678634'), Person('865564635', '635654645')],
    'Servidores': [Person('1549', '2652'), Person('24233', '2365'), Person('5498', '4672')]
}

users = [ [],[],[] ]
pessoa = []
listJson = []
listAcessos = {}
listPassou = []
listNegado = []
roles = ["Professores","Alunos","Servidores"]
cont = 0

#########funcoes########

def func(number, person):
    return person[number]

def mostra():
    num = 0
    global listusers
    listusers = 'Lista Passou:'
    for i in listPassou:
        listusers+= ('<li>'+ str(num) +'. CPF: '+ i.split(' ')[0] + ' MATRICULA: '+i.split(' ')[1]+'</li>\n')
        num+=1
    listusers+='<br></br>'
    num=0
    listusers += 'Lista Negada:\n'
    for j in listNegado:
        listusers+= ('<li>'+ str(num) +'. CPF: '+ j.split(' ')[0] + ' MATRICULA: '+j.split(' ')[1]+'</li>\n')
        num+=1
    listusers+='<br></br>'
    return (listusers)


#########html##########


def html_listaUsuarios ():
    html = """<html>
                <body>
                <h1>Lista:</h1>
                <ul>
                """+'\n'+mostra()+"""
                </ul>
                </body>
                </html>"""
    return html


def html_listaUsuariosJson ():
    return json.dumps(personsTest, indent=4)


def html_sucesso ():
    html = """<html>
                <body>
                <h1>Sucesso</h1>
                <a href="http://127.0.0.1:5000/index"> Lista acessos </a><br>
                </body>
                </html>"""
    return html


def html_acesso(msg):
    html = """<html>
                <body>
                <form action = "/acesso" method = "post">
                {}
                </body>
                </html>""".format(msg)
    return html


##Pegar dados dos registros do cpp
def html_getcpp():
    html = """<html>
                <body>
                <h1>Nao deu!</h1
                <form action = "/acesso" method = "post">
                </body>
                </html>""".format(msg)
    return html


###########Rotas##########

@app.route('/recebe', methods = ['POST'])
def recebendo():
    if request.method == 'POST':
        global cont
        ###### Bug que o Peter debugou
        data = []
        for _ in request.form:
            data.append(json.loads(_))
        data = data[0]

        for i in data['Aceitos']:
            listPassou.append(i)
            cont += 1

        for i in data['Rejeitados']:
            listNegado.append(i)
            cont+=1

        return 'true'
    return 'false'

@app.route('/getRegisters')
def get():
    return html_listaUsuariosJson()

@app.route('/')
@app.route('/index')
def idx():
    return html_listaUsuarios()
